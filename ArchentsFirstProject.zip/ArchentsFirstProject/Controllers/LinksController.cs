﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ArchentsFirstProject.Controllers
{
    public class LinksController : Controller
    {
        // GET: Links
        public ActionResult Refund()
        {
            return View();
        }

        public ActionResult SizeGuide()
        {
            return View();
        }

        public ActionResult WearCare()
        {
            return View();
        }

        public ActionResult ShippingInfo()
        {
            return View();
        }

        public ActionResult ContactUs()
        {
            return View();
        }

        public ActionResult Hiring()
        {
            return View();
        }

        public ActionResult Terms()
        {
            return View();
        }
    }
}